Networ Tester Portable Version 
====================== 
 
1. Click "start.bat" to run the program 
2. This version is portable and can be copied to a USB drive 
3. All configurations and data are stored in the program directory 
